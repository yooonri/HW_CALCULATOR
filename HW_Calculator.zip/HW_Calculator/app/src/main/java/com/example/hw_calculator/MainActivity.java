package com.example.hw_calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private double first, second;
    private Boolean isOperationClick;
    private String operation;

    @Override
    protected void onCreate(Bundle saveInstantState) {
        super.onCreate(saveInstantState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.text_view);
    }

    public void onNumberClick (View view) {
        switch (view.getId()) {
            case R.id.n1:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("1");
                } else (isOperationClick) {
                    textView.setText("1");
                } if{
                    textView.append("1");
                }
                isOperationClick = false;
                break;
            case R.id.n2:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("2");
                } else if (isOperationClick) {
                    textView.setText("2");
                } else {
                    textView.append("2");
                }
                isOperationClick = false;
                break;
            case R.id.n3:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("3");
                } else if (isOperationClick) {
                    textView.setText("3");
                } else {
                    textView.append("3");
                }
                isOperationClick = false;
                break;
            case R.id.n4:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("4");
                } else if (isOperationClick) {
                    textView.setText("4");
                } else {
                    textView.append("4");
                }
                isOperationClick = false;
                break;
            case R.id.n5:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("5");
                } else if (isOperationClick) {
                    textView.setText("5");
                } else {
                    textView.append("5");
                }
                isOperationClick = false;
                break;
            case R.id.n6:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("6");
                } else if (isOperationClick) {
                    textView.setText("6");
                } else {
                    textView.append("6");
                }
                isOperationClick = false;
                break;
            case R.id.n7:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("7");
                } else if (isOperationClick) {
                    textView.setText("7");
                } else {
                    textView.append("7");
                }
                isOperationClick = false;
                break;
            case R.id.n8:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("8");
                } else if (isOperationClick) {
                    textView.setText("8");
                } else {
                    textView.append("8");
                }
                isOperationClick = false;
                break;
            case R.id.n9:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("9");
                } else if (isOperationClick) {
                    textView.setText("9");
                } else {
                    textView.append("9");
                }
                isOperationClick = false;
                break;
            case R.id.n0:
                if (textView.getText().toString().equals("0")) {
                    textView.setText("0");
                } else if (isOperationClick) {
                    textView.setText("0");
                } else {
                    textView.append("0");
                }
                isOperationClick = false;
                break;
            case R.id.btn_clear:
                textView.setText("0");
                first = 0;
                second = 0;
                isOperationClick = false;
                break;
            case R.id.btn_point:
                if (!textView.getText().toString().contains(".")) {
                    textView.append(".");
                    break;
                }
        }
    }

    public void onOperationClick(View view) {
        switch (view.getId()) {
            case R.id.btn_percent:
                first = Double.parseDouble(textView.getText().toString());
                Double result = Double.valueOf(0);
                isOperationClick = true;
                operation = "/";
                switch (operation) {
                    case "/":
                        result = first / 100;
                        break;
                }
                textView.setText(new DecimalFormat("##.######").format(result));
                break;
            case R.id.btn_plusMinus:
                first = Double.parseDouble(textView.getText().toString());
                double resultW = Float.valueOf(0);
                isOperationClick = true;
                operation = "+ -";
                resultW = first * (-1);

                textView.setText(new DecimalFormat("##.######").format(resultW));
                break;
            case R.id.btn_plus:
                firstVariable();
                isOperationClick = true;
                operation = "+";
                break;
            case R.id.btn_minus:
                firstVariable();
                isOperationClick = true;
                operation = "-";
                break;
            case R.id.btn_devide:
                firstVariable();
                isOperationClick = true;
                operation = "/";
                break;
            case R.id.btn_times:
                firstVariable();
                isOperationClick = true;
                operation = "*";
                break;
            case R.id.btn_equals:
                secondVariable();
                Double resultS = Double.valueOf(0);
                switch (operation) {
                    case "+":
                        result = first + second;
                        textView.setText(result.toString());
                        break;
                    case "-":
                        result = first - second;
                        textView.setText(result.toString());
                        break;
                    case "*":
                        result = first * second;
                        textView.setText(result.toString());
                        break;
                    case "/":
                        result = first / second;
                        textView.setText(result.toString());
                        break;
                }
                break;

        }
    }
    public void firstVariable(){
        first=Double.parseDouble(textView.getText().toString());
    }
    public void secondVariable(){
        second=Double.parseDouble(textView.getText().toString());
    }
}